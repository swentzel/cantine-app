# Cantine-App backend

Backend for the cantine-app.


# Install

You can compile the ts files in this directory by 1st installing typescript via

`npm install -g typescript`

then

`npm i`

## Compile TypeScript
You can then run the compiler by running `tsc` in this directory. It will pull the settings from .tsconfig and extra @types
from package.json. The output create.js file is what will be uploaded by serverless.
